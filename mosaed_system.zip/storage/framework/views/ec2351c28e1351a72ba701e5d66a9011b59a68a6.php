<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="img/LOGO-.ico">
    <title>مساعِد</title>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/media.css')); ?>">
</head>

<body dir="rtl">
    <div class="wrapper LoginPage">
        <div class="contentLogin">
            <div class="row ">
                <div class="col-md-5 logoImg">
                    <img src="img/LOGO .svg">
                </div>
                <div class="col-md-7 loginInfo">
                    <p class="headingPage">تسجيل الدخول</p>
                    <!--form class="formLogin"-->
                    <form class="formLogin" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <!--div class="formControl">
                            <input type="text" class="input-name" id="input-name" placeholder="اسم المستخدم">
                        </div-->
                 <div class="formControl">
                   <input id="email" type="email" placeholder="اسم المستخدم او البريد" class="input-name <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="invalid-feedback" role="alert">
                             <strong><?php echo e($message); ?></strong>
                         </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>

                <div class="formControl">
                  <input id="password" type="password" placeholder=" كلمةالمرور " class="input-name <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     name="password" required autocomplete="current-password">
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                          <strong> كلمة المرور خطا </strong>
                        </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-check checkSec">
                    <div class="checkBoxline">
                        <input class="form-check-input  remmberCheckBox" type="checkbox" value="تذكر كلمة المرور" id="defaultCheck1"
                          name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> required>

                           <label class="form-check-label remmberPassword" for="remember defaultCheck1">
                               <?php echo e(__('تذكر كلمة المرور ')); ?>

                            </label>
                </div>


                            <div class="loginBotton">
                                <button type="submit" class="loginBtn">
                                    <?php echo e(__('تسجيل الدخول')); ?>

                                </button>
                          </div>
                      </div>
                       <div class="goSignUp">
                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link"class="passWordQuestion" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('هل نسيت كلمة المرور ؟')); ?>

                                    </a>
                                <?php endif; ?>
                                <br>
                                <span>ليس لديك حساب؟</span><a href="<?php echo e(url('register')); ?>">التسجيل </a><span>
                            </div>


                          <!--div class="loginBotton">
                         <button class="loginBtn">تسجيل الدخول</button>
                        </div>
                         </div>
                          <div class="goSignUp">
                              <p class="passWordQuestion">هل نسيت كلمة السر؟</p>
                            <span>ليس لديك حساب؟</span><a href="signup.html">التسجيل </a>
                        </div-->
                    </form>

                </div>
            </div>
        </div>
    </div>

    <!-- Js Files -->
    <script src="js/jQuery.js"></script>
    <script src="js/banddle.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\mosaed_system\resources\views/auth/login.blade.php ENDPATH**/ ?>