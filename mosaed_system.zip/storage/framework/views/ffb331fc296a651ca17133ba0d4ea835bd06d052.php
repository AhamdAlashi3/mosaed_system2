<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="img/LOGO-.ico">
    <title>مساعِد</title>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/media.css')); ?>">
</head>
<body dir="rtl">
    <div class="wrapper signUpPage">
        <div class="content">
          <div class="head">
            <div class="logo">
                <img src="img/LOGO .svg">
            </div>
            <p class="heading">التسجيل </p>
          </div>
        <form method="POST" action="<?php echo e(route('register')); ?>">
          <?php echo csrf_field(); ?>
          <div class="SingUpInfo">
              <div class="AllInput">

                <div class=" formControl">
                  <!--nput type="text" class="inputName" id="inputName" placeholder="اسم الحلقات" required-->
                  <input id="inputName" type="text"class="inputName <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                  name="name" placeholder="اسم الحلقات" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="formControl">
                <input id="honor" type="text" class="inputName <?php $__errorArgs = ['honor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                 name="honor"  required  placeholder="إسم مشرف الحلقات">

                </div>
                <div class="formControl">
                <input id="phone" type="text" class="inputName <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                 name="phone" required  placeholder="رقم الهاتف">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="formControl">
                <input id="email" type="email" class="inputName <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                 name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="البريد الالكتروني ">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="formControl">
                    <input id="password "  type="password" class="inputName <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="password" required autocomplete="new-password" placeholder="كلمة مرور المشرف">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="formControl">
                  <!--input type="text" class="inputName" id="inputName" placeholder=" رقم هوية مشرف الحلقات"required-->
                  <input id="password-confirm" type="password" class="inputName" name="password_confirmation"
                  required autocomplete="new-password" placeholder="تاكيد كلمة المرور">
                </div>

                <!--div class="formControl">
                  <input type="tel" class=" inputName" id="inputName" placeholder=" البحرين 973+"required>
                </div>
                <div class="formControl">
                  <input type="email" class=" inputName" id="inputName" placeholder="البريد الإلكتروني" required>
                </div-->
                <!--div class="formControl">
                    <button class="SignUpBtn">التسجيل</button>
                </div-->

              <!----->

                  <div class="formControl">
                     <button type="submit" class="SignUpBtn">
                       <?php echo e(__('التسجيل')); ?>

                      </button>
                 </div>

              <!----->
              <!---->
              <div class="goAccount">
                  <span>هل لديك حساب؟</span><a href="login">تسجيل دخول</a>
              </div>
              <!----->
              </div>
            </div>
        </div>
    </div>
</form>
    <!-- Js Files -->
    <script src="js/jQuery.js"></script>
    <script src="js/banddle.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\mosaed_system\resources\views/auth/register.blade.php ENDPATH**/ ?>