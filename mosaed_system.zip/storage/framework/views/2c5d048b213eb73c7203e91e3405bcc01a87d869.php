<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="img/LOGO-.ico">
    <title>المساقات</title>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/media.css')); ?>">
</head>
<body dir="rtl">
  <div class="homeContent">
    <div class="home">
      <side class="sideBar">
        <div class="userImg"><img src="img/LOGO .svg"></div>
        <a href="home"><p class="sideBarItem">الصفحة الرئيسية</p></a>
        <a href="masaqats"><p class="sideBarItem">المساقات </p></a>
        <a href="halaqts"><p class="sideBarItem">الحلقات </p></a>
        <a href="teacherDatas"><p class="sideBarItem">المعلمين </p></a>
        <a href="studentDatas"><p class="sideBarItem">الطلاب </p></a>
        <a href="register"><p class="sideBarItem">التقارير </p></a>

        <div class="person">
          <div class="row ">
            <div class="col-4 mohamedImg">
            </div>
            <div class="col-8">
              <p sideBarItem> الإداري : <?php echo e(Auth::user()->name); ?> </p>
            </div>
            <a  href="<?php echo e(route('logout')); ?>"
          onclick="event.preventDefault();
          document.getElementById('logout-form').submit();">
          <p class="sideBarItem"><?php echo e(__('تسجيل الخروج')); ?></p>
        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
          </div>
        </div>
      </side>
      <div class="home-content">
        <section class="navHome">
        <h1 class="upHeading masaqtHeading">المساقات</h1>
        <div class="barIcon">
          <button class="navbar-toggler iconColor" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-card-text iconNav" viewBox="0 0 16 16">
            <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z"/>
            <path d="M3 5.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3 8a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 8zm0 2.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5z"/>
          </svg>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <div class="sideBarSmall">
            <div class="userImg"><img src="img/LOGO .svg"></div>
            <a href="index.html"><p class="sideBarItem">الصفحة الرئيسية</p></a>
            <a href="masaqat"><p class="sideBarItem">المساقات </p></a>
            <a href="./halaqts"><p class="sideBarItem">الحلقات </p></a>
            <a href="teacherData.html"><p class="sideBarItem">المعلمين </p></a>
            <a href="studentData.html"><p class="sideBarItem">الطلاب </p></a>
            <a href="register"><p class="sideBarItem">التقارير </p></a>



              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
             </form>
            <div class="person">
              <div class="row ">
                <div class="col-4 mohamedImg">
                </div>
                <div class="col-8">
                  <p sideBarItem> الإداري : محمد خليل </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
      </section>
      <?php if(session()->has('Add')): ?>
				   <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
                      <strong><?php echo e(session()->get('Add')); ?></strong>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
					  </button>
				   </div>
        <?php endif; ?>
        <?php if(session()->has('Error')): ?>
				   <div class="alert alert-danger alert-dismissible fade show text-center" role="alert" dir="rtl">
                      <strong><?php echo e(session()->get('Error')); ?></strong>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
					  </button>
				   </div>
        <?php endif; ?>
        <?php if(session()->has('delete')): ?>
				   <div class="alert alert-danger alert-dismissible fade show text-center" role="alert" dir="rtl">
                      <strong><?php echo e(session()->get('delete')); ?></strong>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
					  </button>
				   </div>
        <?php endif; ?>
        <?php if(session()->has('Edit')): ?>
				   <div class="alert alert-success alert-dismissible fade show text-center" role="alert" dir="rtl">
                      <strong><?php echo e(session()->get('Edit')); ?></strong>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
					  </button>
				   </div>
				<?php endif; ?>
      <section class="AllMasaqContent">
      <section class="masaqSec">
      <div class="addMasaqBtn">

          <button class="masaqBtn masaqBtn1 " onclick="addFunction()">إضافة مساق</button>
      </div>
       <div class="masaqName">
           <h3>المساقات</h3>
           <!--div class="line"></div-->
           <div class="row masaqActive">
               <div class="col-2">
                <div class="dropdown">
                    <button onclick="myFunction()" class="dropbtn" >
                    <!--svg xmlns="http://www.w3.org/2000/svg" width="30" height="30"
                    fill="currentColor" class="bi bi-three-dots-vertical svgIcon dropbtn"
                    viewBox="0 0 16 16">
                        <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3
                        0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5
                         0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/>
                      </svg--></button>
                    <!--div id="myDropdown" class="dropdown-content">
                      <a href="#home">تعديل</a>
                      <a href="#about">مسح</a>
                    </div-->
                  </div>
               </div>

								<div class="table-responsive ">
                 <table id="example" class="table key-buttons text-md-nowrap">
										<thead>
											<tr >
												<th class="border-bottom-0" style="font-size:16px">#</th>
                        <th class="border-bottom-0"style="font-size:16px">اسم المساق</th>
                        <th class="border-bottom-0" style="font-size:16px">العمليات</th>

											</tr>
                    </thead>
                    <tbody>
											<?php $n=0;?>
											<?php $__currentLoopData = $masaqat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php $n++;?>
											<tr>
												<td><?php echo e($n); ?></td>
                        <td title="المساق"><?php echo e($row->section); ?></td>
                        <td>
												 <!--a class="modal-effect btn btn-sm btn-info"
                          data-effect="effect-scale" data-id="<?php echo e($row->id); ?>"
                          data-section ="<?php echo e($row->section); ?>"
                          data-toggle="modal" href="#exampleModal2" title="تعديل">
                         <i class="las la-pen"></i></a-->

                    <a class="btn btn-outline-success btn-sm"
									     data-id ="<?php echo e($row->id); ?>"
										   data-section="<?php echo e($row->section); ?>"
										   data-toggle="modal"
                       href="#Edit_section" title="Edit">تعديل</a>

                       <a class="btn btn-outline-danger btn-sm"
									     data-id ="<?php echo e($row->id); ?>"
										   data-section="<?php echo e($row->section); ?>"
										   data-toggle="modal"
										   href="#Delete_section" title="Delete">حذف</a>

												 <!--a class="modal-effect btn btn-sm btn-danger"
												 data-effect="effect-scale" data-id="<?php echo e($row->id); ?>"
												 data-section ="<?php echo e($row->section); ?>"
												 data-toggle="modal" href="#Example_Delete" title="حذف">
                          <i class="las la-trash"></i></a-->
												</td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                 </table>
                </div>
               <!--div class="col-8 nameOfMasaq">

               <?php $__currentLoopData = $masaqat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <p><?php echo e($row->section); ?></p>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div-->

               <!--div class="line"></div-->
           </div>
       </div>
    </section>
    <section class="newMasaq">
        <h2>إضافة مساق</h2>
        <form action="<?php echo e(route('masaqat.store')); ?>" method="post">
						  <?php echo e(csrf_field()); ?>

            <input type="text" class="input-name enterMasaqName" id="input-name"  name="section" placeholder="اسم المساق">
            <button class="masaqBtn addBtn" type="submit">إضافة </button>
        </form>
    </section>
    </section>
    <!-- Basic modal Edit Sections-->
		<div class="modal" id="Edit_section">
			<div class="modal-dialog" role="document">
				<div class="modal-content modal-content-demo">
						<div class="modal-header">
						   <h6 class="modal-title">تعديل المساق</h6>
						   <button aria-label="Close" class="close" data-dismiss="modal" type="button">
						   <span aria-hidden="true">&times;</span></button>
						</div>
					<div class="modal-body">
            <form action="masaqats/update" method="post">
            <?php echo e(method_field('PATCH')); ?>

						<?php echo e(csrf_field()); ?>


							<div class="form-group">
							  <label for="section" style="margin-left:80%">إسم المساق</label>
							  <input type="hidden" name="id" id="id">
							  <input type="text" name="section" id="section" class="form-control" >
							</div>
							<div class="modal-footer">
								<button class="btn  btn-success" type="submit">تاكيد</button>
								<button class="btn  btn-secondary" data-dismiss="modal" type="button">إلغاء</button>
							</div>
            </form>
          </div>
				</div>
			</div>
		</div>
    <!-- End Basic modal  Edit section-->
    <!-- Basic modal Delete Sections-->
		<div class="modal" id="Delete_section">
			<div class="modal-dialog" role="document">
				<div class="modal-content modal-content-demo">
						<div class="modal-header">
						   <h6 class="modal-title">حذف المساق</h6>
						   <button aria-label="Close" class="close" data-dismiss="modal" type="button">
						   <span aria-hidden="true">&times;</span></button>
						</div>
					<div class="modal-body">
            <form action="masaqats/destroy" method="POST">
            <?php echo e(method_field('delete')); ?>

						<?php echo e(csrf_field()); ?>


							<div class="form-group">
							  <label for="section" class="text-danger" style="margin-left:50%">هل انت متاكد من عملية الحذف ؟</label>
							  <input type="hidden" name="id" id="id">
							  <input type="text"   name="section" id="section" class="form-control" readonly>
							</div>
							<div class="modal-footer">
								<button class="btn  btn-danger" type="submit">تاكيد</button>
								<button class="btn  btn-info" data-dismiss="modal" type="button">إلغاء</button>
							</div>
            </form>
          </div>
				</div>
			</div>
		</div>
		<!-- End Basic modal  Delete section-->
  </div>
  </div>
    <!-- Js Files -->
    <script src="<?php echo e(asset('js/jQuery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/banddle.js')); ?>"></script>
    <script src="<?php echo e(asset('js/icon.js')); ?>"></script>
    <!--Internal  Datatable js -->
    <script src="<?php echo e(asset('js/table-data.js')); ?>"></script>
    <script src="<?php echo e(asset('js/modal-popup.js')); ?>"></script>
    <script src="<?php echo e(asset('js/modal.js')); ?>"></script>

<!--script>
	$("#Edit_section").on('show.bs.modal', function(event){
		var button = $(event.relatedTarget)
		var id      = button.data('id')
    var section = button.data('section')
    var modal   = $(this)
    modal.find('.moda-body #id').val(id);
		modal.find('.moda-body #section').val(section);

 	})

</script-->

<script>
$('#Edit_section').on('show.bs.modal',function(event){
	   var button = $(event.relatedTarget)
	   var id       = button.data('id')
	   var section = button.data('section')
	   var modal = $(this)
	   modal.find('.modal-body #id').val(id);
	   modal.find('.modal-body #section').val(section);

   })

  </script>
  <script>
$('#Delete_section').on('show.bs.modal',function(event){
	   var button = $(event.relatedTarget)
	   var id       = button.data('id')
	   var section = button.data('section')
	   var modal = $(this)
	   modal.find('.modal-body #id').val(id);
	   modal.find('.modal-body #section').val(section);

   })

  </script>

</body>
</html>
<!--script>
$('#Edit_section').on('show.bs.modal',function(event){
	   var button = $(event.relatedTarget)
	   var id       = button.data('id')

	   var section = button.data('section')

	   var modal = $(this)
	   modal.find('.modal-body #id').val(id);
	   modal.find('.modal-body #section').val(section_name);

   })

  </script-->
<?php /**PATH C:\xampp\htdocs\mosaed_system\resources\views/masaqats.blade.php ENDPATH**/ ?>