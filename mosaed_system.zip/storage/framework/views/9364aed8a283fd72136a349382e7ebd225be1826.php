<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="img/LOGO-.ico">
    <title>بيانات الطلاب</title>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/all.css">
    <link rel="stylesheet" href="css/media.css">
</head>
<body dir="rtl">
  <div class="homeContent">
    <div class="home">
      <side class="sideBar">
        <div class="userImg"><img src="img/LOGO .svg"></div>
        <a href="home"><p class="sideBarItem">الصفحة الرئيسية</p></a>
        <a href="masaqats"><p class="sideBarItem">المساقات </p></a>
        <a href="halaqts"><p class="sideBarItem">الحلقات </p></a>
        <a href="teacherDatas"><p class="sideBarItem">المعلمين </p></a>
        <a href="studentDatas"><p class="sideBarItem">الطلاب </p></a>
        <a href="<?php echo e(url('register')); ?>"><p class="sideBarItem">التقارير </p></a>
        <form id="logout-form" action="<?php echo e(url('register')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>

        <div class="person">
          <div class="row ">
            <div class="col-4 mohamedImg">
            </div>
            <div class="col-8">
           <p sideBarItem> الإداري : <?php echo e(Auth::user()->name); ?></p>
            </div>
            <a  href="<?php echo e(route('logout')); ?>"
          onclick="event.preventDefault();
          document.getElementById('logout-form').submit();">
          <p class="sideBarItem"><?php echo e(__('تسجيل الخروج')); ?></p>
        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
          </div>
        </div>
      </side>
      <div class="home-content">
        <section class="navHome">
        <h1 class="upHeading">بيانات الطلاب</h1>
        <div class="barIcon">
          <button class="navbar-toggler iconColor" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-card-text iconNav" viewBox="0 0 16 16">
            <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z"/>
            <path d="M3 5.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3 8a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 8zm0 2.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5z"/>
          </svg>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <div class="sideBarSmall">
            <div class="userImg"><img src="img/LOGO .svg"></div>
            <a href="home"><p class="sideBarItem">الصفحة الرئيسية</p></a>
            <a href="masaqats"><p class="sideBarItem">المساقات </p></a>
            <a href="halaqts"><p class="sideBarItem">الحلقات </p></a>
            <a href="teacherDatas"><p class="sideBarItem">المعلمين </p></a>
            <a href="studentDatas"><p class="sideBarItem">الطلاب </p></a>
            <a href="#"><p class="sideBarItem">التقارير </p></a>
            <a  href="<?php echo e(route('logout')); ?>"
          onclick="event.preventDefault();
          document.getElementById('logout-form').submit();">
          <p class="sideBarItem"><?php echo e(__('تسجيل الخروج')); ?></p>
        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
            <div class="person">
              <div class="row ">
                <div class="col-4 mohamedImg">
                </div>
                <div class="col-8">
                   <p sideBarItem> الإداري : <?php echo e(Auth::user()->name); ?></p>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
      </section>
      <?php if(session()->has('Add')): ?>
				   <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
                      <strong><?php echo e(session()->get('Add')); ?></strong>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
					  </button>
				   </div>
        <?php endif; ?>
        <?php if(session()->has('Error')): ?>
				   <div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
                      <strong><?php echo e(session()->get('Error')); ?></strong>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
					  </button>
				   </div>
        <?php endif; ?>
        <?php if(session()->has('import')): ?>
				   <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
                      <strong><?php echo e(session()->get('import')); ?></strong>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
					  </button>
				   </div>
        <?php endif; ?>
        <?php if(session()->has('import_error')): ?>
				   <div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
                      <strong><?php echo e(session()->get('import_error')); ?></strong>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
					  </button>
				   </div>
        <?php endif; ?>
      <section class="AllDataContent">
        <div class="addHalaqtSec InfoSec">
        <form  action="<?php echo e(route('studentDatas.store')); ?>" method="post">
						  <?php echo e(csrf_field()); ?>

              <div class="addHalaqt firstData">
                <!--select name="halaqaName" id="halaqaName">
                    <option value="zOption" selected style="display: none;">اسم المساق  </option>
                    <option value="fOption">تحفيظ القرآن الكريم</option>
                    <option value="sOption">تثبيت القرآن الكريم</option>
                    <option value="TOption">أحكام التلاوة والتجويد</option>
                  </select-->
                  <select name="masaqat" id="halaqaName" >
                    <!--option value="zOption" selected style="display: none;">اسم المساق  </option-->
                    <option selected disabled>إختار المساق</option>
                      <?php $__currentLoopData = $masaqat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $masaqats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($masaqats->id); ?>"><?php echo e($masaqats->section); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <!--input type="text" class="input-name halaqaInput " id="input-name" placeholder="اسم الحلقة"-->
                <select name="halaqt" id="halaqaName" >
                    <!--option value="zOption" selected style="display: none;">اسم المساق  </option-->
                    <option selected disabled>اسم الحلقة</option>
                      <?php $__currentLoopData = $halaqts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaqt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($halaqt->id); ?>"><?php echo e($halaqt->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="addHalaqt">
                <input type="text" class="input-name halaqaInput " id="input-name"
                 placeholder="الرقم الشخصي" name="ID_person">
                <input type="text" class="input-name halaqaInput " id="input-name"
                 placeholder="رقم الهاتف" name="phone_number">
                <input type="email" class="input-name halaqaInput " id="input-name"
                placeholder=" البريد الإلكتروني" name="email" required>
              </div>
              <div class="addHalaqt">
                <input type="text" class="input-name halaqaInput " id="input-name"
                placeholder="الإسم " name="Name">
                <input type="date" class="input-name halaqaInput " id="input-name"
                placeholder="تاريخ الميلاد" name="Date">
                <select name="Nationality" id="halaqaName">
                  <option value="zOption" selected style="display: none;">الجنسية   </option>
                  <option value="فلسطيني"> فلسطيني </option>
                  <option value="إماراتي">  إماراتي</option>
                  <option value="مصري">مصري</option>
                  <option value="سعودي">سعودي</option>
                  <option value="لبناني">لبناني</option>
                  <option value="سوري">سوري</option>
                  <option value="سوداني">سوداني</option>
                </select>
              </div>
              <div class="addHalaqt buttons">
                <div class="addMasaqBtn">
                  <button class="masaqBtn">إضافة </button>
                </div>
                <div class="addMasaqBtn">
                <a class="masaqBtn text-white" style="text-decriton:none" href="<?php echo e(URL('export_Student')); ?>">
                  <i class="fa fa-file-download"></i>&nbsp;&nbsp;نموذج </a>
                  <!--button class="masaqBtn  "> إستيراد</button-->
              </div>
            </form>
            <form  method="POST" enctype="multipart/form-data" action="<?php echo e(url('import_Student')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('GET')); ?>

            <!--label>Choose CSV</label-->
              <input type="file" name="file" required>
                  <button class="masaqBtn text-white"type="submit" >
                  <i class="fa fa-file-upload"></i>&nbsp;&nbsp;إستيراد</button>
                  <btton>
              </div>
        </div>
        <section class="tableSec">
        <table id="example" class="table table-borderd">
          <thead>
          <tr>
            <th>الاسم</th>
            <th>رقم الهاتف</th>
            <th>البريد الإلكتروني</th>
          </tr>
         </thead>
         <tbody>
						<?php $__currentLoopData = $studentDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
               <td title="الحلقة"><?php echo e($student->Name); ?></td>
               <td title="المساق"><?php echo e($student->phone_number); ?></td>
               <td title="البريد الاللكتروني"><?php echo e($student->email); ?></td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
         </table>
        </section>
    </section>
      </div>
  </div>
  </div>
    <!-- Js Files -->
    <script src="<?php echo e(asset('js/jQuery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/banddle.js')); ?>"></script>
    <script src="<?php echo e(asset('js/icon.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\mosaed_system\resources\views/studentDatas.blade.php ENDPATH**/ ?>